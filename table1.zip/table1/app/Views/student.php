<html>
<head>
<style>
div {
	align:center;
	width:400px;
	height:300px;
  border: solid black;
  background-color:white;
  padding: 20px;
}
 
</style>
</head>
<body>
<div>
<h3>Enter data for Student</h3>
<form name="stud" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="GET">
Name:<br /> 
<input type="text" name="fname1"/><br />
Roll number:<br />
<input type="text" name="rno1"/>
<br><br>
<input type="submit" name="submit" value="submit" />
</form>
<?php  

$localhost = "localhost";
$username = "root";
$password = "";
$dbname="db_data";

// Create connection
$conn = new mysqli($localhost, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
 
  die("Connection failed: " . $conn->connect_error);
}
  echo "Connected successfully" . "<br>";


if(isset($_GET['submit'])){
    $f_name = $_GET['fname1'];
    $r_no = $_GET['rno1'];   
    $sql= "INSERT INTO student (fname, rno) VALUES ('$f_name','$r_no')";
    echo $f_name ;
    echo $r_no ;


  $sql1 = "INSERT INTO student (fname, rno) VALUES ('Sona', '1234')";
  
    if ($conn->query($sql1) === TRUE) {
      echo "New record created successfully";
    } else {
      echo "Error: " . $sql1 . "<br>" . $conn->error;
    }

 
$sqldata = "SELECT * FROM student";
$result = $conn->query($sqldata);

  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      echo "Name: " . $row["fname"]. " - Roll Number: " . $row["rno"]. "<br>";
    }
  } else {
    echo "0 results";
  }
}
$conn->close();
?> 
</div>
</body>
</html>