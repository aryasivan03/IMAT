<!-- PHP code to establish connection with the localserver -->
<?php
 
 $localhost = "localhost";
 $username = "root";
 $password = "";
 $dbname="db_data";
 
 // Create connection
 $conn = new mysqli($localhost, $username, $password, $dbname);
 
 // Check connection
 

   
   
  

?>
<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta charset="UTF-8">
    <title>Student Details</title>
    <!-- CSS FOR STYLING THE PAGE -->
    <style>
        table {
            margin: 0 auto;
            font-size: large;
            border: 1px solid black;
        }
 
        h1 {
            text-align: center;
            color: #006600;
            font-size: xx-large;
            font-family: 'Gill Sans', 'Gill Sans MT',
            ' Calibri', 'Trebuchet MS', 'sans-serif';
        }
 
        td {
            background-color: #E4F5D4;
            border: 1px solid black;
        }
 
        th,
        td {
            font-weight: bold;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
 
        td {
            font-weight: lighter;
        }
    </style>
</head>
 
<body>
    <section>
        <h1>Student Details</h1>
        <!-- TABLE CONSTRUCTION -->
        <table>
            <tr>
                <th>NO</th>
                <th>NAME</th>
                <th>COURSE</th>
            </tr>
            <!-- PHP CODE TO FETCH DATA FROM ROWS -->
         
           
                
            <?php
            $sql = "SELECT * FROM data1 WHERE Course='BBA'";
            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
              // output data of each row
              while($row = $result->fetch_assoc()) {

            ?>
            <tr>
                <!-- FETCHING DATA FROM EACH
                    ROW OF EVERY COLUMN -->
                    <td><?php echo $row["No"];?></td>
                    <td><?php echo $row["SName"];?></td>
                    <td><?php echo $row["Course"];?></td>

            <?php
                }
               }
            ?>   
                    </tr>
        
        </table>
    </section>
</body>
 
</html>


</html>

