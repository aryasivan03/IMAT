<?php
    $localhost = "localhost";
    $username = "root";
    $password = "";
    $dbname="db_data";
 
    // Connect to database
    $conn = new mysqli($localhost, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
      }
        echo "Connected successfully" . "<br>";

  
    // Get all the categories from category table
    $sql = "SELECT * FROM `data1`";
    $all_data1 = mysqli_query($conn,$sql);
  
    // The following code checks if the submit button is clicked
    // and inserts the data in the database accordingly
    if(isset($_POST['submit']))
    {
        // Store the Product name in a "name" variable
        $s_name = mysqli_real_escape_string($conn,$_POST['SName']);
        
        // Store the Category ID in a "id" variable
        $d_id = mysqli_real_escape_string($con,$_POST['dep_id']);
        
        // Creating an insert query using SQL syntax and
        // storing it in a variable.
        //$sql_select ="INSERT INTO `product`(`product_name`, `category_id`) VALUES ('$name','$id')";


    
        $sql_select = "SELECT * FROM data1 WHERE SName='$s_name' AND dep_id='$d_id'";
        $result = $conn->query($sql_select);

        if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
         echo $row["No"];
         echo $row["SName"];
         echo $row["Course"];
         echo $row["dep_name"];
            }
        }


          // The following code attempts to execute the SQL query
          // if the query executes with no errors
          // a javascript alert message is displayed
          // which says the data is inserted successfully
          if(mysqli_query($conn,$sql_select))
        {
            echo '<script>alert("Product added successfully")</script>';
        }
    }
?>
  
  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">   
</head>
<body>
    <form method="POST">
        <!--<label>Name of Product:</label>
        <input type="text" name="Product_name" required><br>-->
        <label>Select Student Name</label>
        <select name="data1">
            <?php
                // use a while loop to fetch data
                // from the $all_categories variable
                // and individually display as an option
                while ($data1 = mysqli_fetch_array(
                        $all_data1,MYSQLI_ASSOC)):;
            ?>
                <option value="<?php echo $data1["No"];
                    // The value we usually set is the primary key
                ?>">
                    <?php echo $data1["SName"];
                        // To show the category name to the user
                    ?>
                </option>
            <?php
                endwhile;
                // While loop must be terminated
            ?>
        </select>






        <select name="department">
            <?php
                // use a while loop to fetch data
                // from the $all_categories variable
                // and individually display as an option
                while ($department = mysqli_fetch_array(
                        $all_department,MYSQLI_ASSOC)):;
            ?>
                <option value="<?php echo $department["dep_id"];
                    // The value we usually set is the primary key
                ?>">
                    <?php echo $department["dep_name"];
                        // To show the category name to the user
                    ?>
                </option>
            <?php
                endwhile;
                // While loop must be terminated
            ?>
        </select>
        <br>
        <input type="submit" value="submit" name="submit">
    </form>
    <br>
</body>
</html>



