<?php
 include('db_config.php');
?>
<html>
    <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <script type="text/javascript">
        document.write(5);
        $(document).ready(function(){
            // Country dependent ajax
            $("#country").on("change",function(){
                var countryId = $(this).val();   
                alert('Country Selected  : ' + countryId);
                $.ajax({
                    url :'db_config.php',
                    type:'POST',
                    cache:false,
                    data:{countryId:countryId},
                    success:function(data){
                        $("#state").html(data);
                        $('#city').html('<option value="">Select city</option>');
                    }
                });
            });
                    
            // state dependent ajax
            $("#state").on("change", function(){
                var stateId = $(this).val();
                $.ajax({
                    url :'action.php',
                    type:'POST',
                    cache:false,
                    data:{stateId:stateId},
                    success:function(data){
                        $("#city").html(data);
                    }
                });
            });
        });
        function myaction(){
            
            alert('Country Select' +countryId);
            url='action.php';
        }
    </script>


    </head>
    <body>
        <h1>Cityssss</h1>
        <div class="container">
 
            <br/>
        <form action="" method="post">
            <div class="col-md-4">
                <!-- Country dropdown -->
                <label for="country">Country</label>
                <select class="form-control" id="country" onchange="myaction()">
                    <option value="">Select Country</option>

                    <?php
                    $query = "SELECT * FROM country";
                    $result = $conn->query($query);
                    if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                    echo '<option value="'.$row['id'].'">'.$row['cname'].'</option>';
                    }
                    }else{
                    echo '<option value="">Country not available</option>';
                    }
                    ?> 
                </select>
                <br/>
                    
                <!-- State dropdown -->
                <label for="">State</label>
                <select class="form-control" id="state">
                    <option value="">Select State</option>
                    
                </select>
                <br/>
                
                <!-- City dropdown -->
                <label for="">City</label>
                <select class="form-control" id="city">
                    <option value="">Select City</option>
                </select>

               <?php
                  // Include the database connection file
                  include('db_config.php');
                  if (isset($_POST['countryId']) && !empty($_POST['countryId'])) {

                  // Fetch state name base on country id
                  $query = "SELECT * FROM tbl_state WHERE country_id = ".$_POST['countryId'];
                  $result = $conn->query($query);
                  if ($result->num_rows > 0) {
                  echo '<option value="">Select State</option>';
                  while ($row = $result->fetch_assoc()) {
                  echo '<option value="'.$row['id'].'">'.$row['sname'].'</option>';
                  echo $result;
                  }
                  } else {
                  echo '<option value="">State not available</option>';
                  }
                  } elseif(isset($_POST['stateId']) && !empty($_POST['stateId'])) {
                  
                  // Fetch city name base on state id
                  $query = "SELECT * FROM city WHERE state_id = ".$_POST['stateId'];
                  $result = $conn->query($query);
                  
                  if ($result->num_rows > 0) {
                  echo '<option value="">Select city</option>';
                  while ($row = $result->fetch_assoc()) {
                  echo '<option value="'.$row['id'].'">'.$row['city_name'].'</option>';
                  }
                  } else {
                  echo '<option value="">City not available</option>';
                  }
                  }
                  ?>


                  <?php 
                  if(isset($_POST['submit'])){ 
                      echo 'Selected Country Code: '.$_POST['country']; 
                      echo 'Selected State Code: '.$_POST['state']; 
                      echo 'Selected City Name: '.$_POST['city']; 
                  } 
                  ?>


                <br/>
                <input type="submit" name="submit">
            </div>
        </form>
        <?php

        ?>
    </body>
</html>



