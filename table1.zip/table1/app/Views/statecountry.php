<!-- PHP code to establish connection with the localserver -->
<?php
 
 $localhost = "localhost";
 $username = "root";
 $password = "";
 $dbname="db_data";
 
 // Create connection
 $conn = new mysqli($localhost, $username, $password, $dbname);
 
 // Check connection

 if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
    echo "Connected successfully" . "<br>";
 
?>
<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta charset="UTF-8">
    <title>Student Details</title>





    
</head>
<body>
        <select id="country">
            <option value="">Select Country</option>
            <?php
            $sql = "SELECT cname FROM country  ORDER BY id ASC";
            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
            ?>
            <option value="0"><?php echo $row["cname"];?></option>
        
            <?php
                }
               }
            ?>  
        </select> 
        
        
        <select id="state">
            <option value="">Select State</option>
            <?php
           
            $sql1=" SELECT sname FROM tbl_state INNER JOIN country ON tbl_state.id = country.id";
            

            $result1= $conn->query($sql1);
            
            if ($result1->num_rows > 0) {
              while($row = $result1->fetch_assoc()) {
            ?>
            <option><?php echo $row["sname"];?></option>
        
            <?php
                }
               }
            ?>   
        </select>


        <select id="city">
            <option value="">Select City</option>
        </select>            
</body> 
</html>
</html>









