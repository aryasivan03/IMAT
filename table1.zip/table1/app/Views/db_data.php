<?php
$localhost = "localhost";
$username = "root";
$password = "";
$dbname="db_data";

// Create connection
$conn = new mysqli($localhost, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
  echo "Connected successfully" . "<br>";



//CREATING NEW TABLE DATA 2

/*$sql = "CREATE TABLE data2 (
  id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fname VARCHAR(30) NOT NULL)";
    
  if ($conn->query($sql) === TRUE) {
    echo "Table data2 created successfully";
  } else {
    echo "Error creating table: " . $conn->error;
  }*/
  



 
//INSERTING RECORDS TO DATA2

/*$sql = "INSERT INTO data2 (id, fname) VALUES ('2', 'Sona')";
  
if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}*/





//INSERTING RECORDS AND GET LAST ID
/*$sql = "INSERT INTO data2 (id, fname) VALUES ('4','Nivya')";

if ($conn->query($sql) === TRUE) {
  $last_id = $conn->insert_id;
  echo "New record created successfully. Last inserted ID is: " . $last_id;
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}*/


//SELECTING DATA 2

/*$sql = "SELECT * FROM data2";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["fname"]. "<br>";
  }
} else {
  echo "0 results";
}*/



//SELECTING  DATA  from data1

$sql = "SELECT * FROM data1 WHERE Department='Commerce' AND Course='BBA'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "No: " . $row["No"]. " - Name: " . $row["Name"]. " - Course: " . $row["Course"].   " Department: " . $row["Department"].    "<br>";
  }
} else {
  echo "0 results";
}








//UPDATE DATA
/*$sql = "UPDATE data2 SET fname='Anju' WHERE id=4";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}*/

$conn->close();
?>