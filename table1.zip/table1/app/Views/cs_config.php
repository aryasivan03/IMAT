<?php 
// Database configuration 
$dbHost     = "localhost"; 
$dbUsername = "root"; 
$dbPassword = ""; 
$dbName     = "country_state"; 
 
// Create database connection 
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName); 
echo "connected";
 
// Check connection 
if ($db->connect_error) { 
    die("Connection failed: " . $db->connect_error); 

}